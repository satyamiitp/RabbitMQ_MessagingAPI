package com.satya.tech.springrabbitmqproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrabbitmqproducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrabbitmqproducerApplication.class, args);
	}

}
