package com.springcloudstreamconsumerjpa.paychex.springcloudstreamconsumerjpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;

    @EnableBinding(Sink.class)
    @SpringBootApplication
    public class SpringcloudstreamconsumerjpaApplication {

        @Autowired
    FoodRepository foodRepository;

    public static void main(String[] args) {
        SpringApplication.run(SpringcloudstreamconsumerjpaApplication.class, args);
    }

    @StreamListener(target = Sink.INPUT)
    public void processCheapMeals(FoodOrder foodOrder){ // This is a consumer method .Messages are getting consumed from RabbitMQ
        System.out.println("This was a great meal!: "+foodOrder);

        FoodOrderJpa foodOrderJpa = new FoodOrderJpa();
        foodOrderJpa.setRestaurant(foodOrder.getRestaurant());
        foodOrderJpa.setCustomerAddress(foodOrder.getCustomerAddress());
        foodOrderJpa.setOrderDescription(foodOrder.getOrderDescription());

        foodRepository.save(foodOrderJpa);


    }

}

