package com.springcloudstreamconsumerjpa.paychex.springcloudstreamconsumerjpa;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FoodRepository extends JpaRepository<FoodOrderJpa,Integer> {

    @Override
    List<FoodOrderJpa> findAll();
}
